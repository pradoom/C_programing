/*E6.4*/
#include<stdio.h>
int add(int x,y,z)
{
	return x+y+z;
}
int main(void)
{
	int sum;
	sum=add(1,2,3);
	return 0;
}
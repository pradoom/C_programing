/*E13_13*/
#include<stdio.h>
#define INT int
int main(void)
{
	INT a=2,*p=&a;
	printf("%d  %d\n",a,*p);
	return 0;
}
/*E3.1*/
#include<stdio.h>
#define MSSG "Hello World\n"
int main(void)
{
	printf(MSSG);
	return 0;
}
/*E9.2*/
#include<stdio.h>
int main(void)
{
	int *ptr;
	printf("Enter a number : ");
	scanf("%d",ptr);
	printf("%d\n",*ptr);
	return 0;
}
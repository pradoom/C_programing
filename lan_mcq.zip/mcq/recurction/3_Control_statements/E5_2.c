/*E5_2*/
#include<stdio.h>
int main(void)
{
	int a=0;
	if(a=0)
		printf("a is zero\t");
	else
		printf("a is not zero\t");
	printf("Value of a is %d\n",a);	
	return 0;
}


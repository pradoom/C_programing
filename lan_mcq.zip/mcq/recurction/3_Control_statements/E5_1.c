/*E5_1*/
#include<stdio.h>
int main(void)
{
	int a=9;
	if(a=5)
		printf("a is five\t");
	else
		printf("a is not five\t");
	printf("Value of a is %d\n",a);	
	return 0;
}
/*E5_6*/
#include<stdio.h>
int main(void)
{
	int i=1, j=9;
	if(i>=5 && j<5);	
        i = j+2;
	printf("%d\n",i);
	return 0;
}


/*E5_13*/
#include<stdio.h>
int main(void)
{
	int a=10,b=80,c=30;
	if(a==10)
	if(b==20)	
	if(c==30)
	printf("a is 10,b is 20, c is 30\n");
	else
	printf("a is 10, b is not 20\n");
	else
	printf("a is not 10\n");
	return 0;
}

/*
#include<stdio.h>
int main(void)
{
	int a=10,b=80,c=30;
	
	if(a==10)
		if(b==20)	
		{
			if(c==30)
				printf("a is 10, b is 20, c is 30\n");
		}
		else
			printf("a is 10, b is not 20\n");
	else
		printf("a is not 10\n");
	return 0;
}
*/
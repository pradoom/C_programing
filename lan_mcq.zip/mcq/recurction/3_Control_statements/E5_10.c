/*E5_10*/
#include<stdio.h>
int main(void)
{
	int i=3,j=2,k=2,l=10,m=1,z=0;
	
	if(i==3)
  	   if(j==k)
          if(l<m)
	         z=100;
	printf("%d\n",z);
	return 0;
}

/*
int main(void)
{
   int i=3, j=2, k=2, l=10, m=1, z=0;

   if(i==3 && j==k && l<m)
		z=100;
   printf("%d\n",z);
   return 0;
}
*/


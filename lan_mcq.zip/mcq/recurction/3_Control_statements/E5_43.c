/*E5_43*/
#include<stdio.h>

int main(void)
{
	int i=0;
	while(i<=5)
		i++;
		printf("%d ",i);
	return 0;
}

/*
int main(void)
{
	int i=0;
	do
		i++;
		printf("%d ",i);
	while(i<=5);
	return 0;
}
*/

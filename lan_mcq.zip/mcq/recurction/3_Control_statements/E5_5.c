/*E5_5*/
#include<stdio.h>
int main(void)
{
	int a=9,b=0,c=0;
	if(!a<10  && !b||c)
            printf("C in depth\n");
    else
            printf("See in depth\n");
	return 0;
}

/*E5_21*/
#include<stdio.h>
int main(void)
{
	int a,b;
	
	while(-1) 
	{ 
		printf("Test Loop\n");
	}   
	

	/*
	while(!0) 
	{ 
		printf("Test Loop\n"); 
	}  
	*/

	/*
	while(0)  
	{ 
		printf("Test Loop\n"); 
	}   
	*/
	
	/*
	a=0; 
	while(a=0) 
	{ 
		printf("Test Loop\n"); 
	}
	*/

	/*
	a=0; 
	while(a=2) 
	{ 
		printf("Test Loop\n"); 
	}   
	*/

	/*
	a=0,b=1; 
	while(a=b)
	{ 
		printf("Test Loop\n"); 
	}  
	*/

	/*
	a=1,b=0; 
	while(a=b)
	{ 
		printf("Test Loop\n"); 
	}
	*/
	return 0;
}

/*E5_8*/
#include<stdio.h>
int main(void)
{
	int a=2,x=10;
	if(a==2)
	    if(x==8)
			printf("a is 2 and x is 8\n");
    else
		printf("a is not 2\n");
	return 0;
}

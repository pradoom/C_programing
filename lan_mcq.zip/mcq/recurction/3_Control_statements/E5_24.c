/*E5_24*/
#include<stdio.h>
int main(void)
{
	int i;
	
	for(i=1; i<5; i++);
		printf("%d ",i);
	
	/*
	i=10;
	while(i<5);  
		printf("%d ",i++);
	*/

	/*
	i=0;
	while(i<5);	
		printf("%d",i++);
	*/
	return 0;
}

/*E5_33*/
#include<stdio.h>
int main(void)
{
	int i=1; 
	do; 
	while(++i<10);
	printf("%d\n",i);
	return 0;
}

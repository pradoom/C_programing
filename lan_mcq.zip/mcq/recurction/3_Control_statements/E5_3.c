/*E5_3*/
#include<stdio.h>
int main(void)
{
	int i=10;
	i==50;
	if(i==50)
	    printf("i is fifty\n");
	else
	    printf("i is not fifty\n");
	return 0;
}

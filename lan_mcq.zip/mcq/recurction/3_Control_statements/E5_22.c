/*E5_22*/
#include<stdio.h>
int main(void)
{
	int i,j;

/*(i)*/ 
	for(i=0; i<10; i++)
		printf("%d ",i);

/*(ii)*/ 
/*	for(i=1; i<=10; i++)
		printf("%d ",i);
*/

/*(iii)*/
/*	for(i=0; i<=10; i++)
		printf("%d ",i);
*/

/*(iv)*/
/*	for(i=1; i<10; i++)
		printf("%d ",i);
*/

/*(v)*/ 
/*	for(i=0; i<=10; i--)   
		printf("%d ",i);
*/

/*(vi)*/ 
/*	for(i=10; i>=1; i--)
		printf("%d ",i);
*/

/*(vii)*/
/*	for(i=10; i>1; i--)
		printf("%d ",i);
*/

/*(viii)*/ 
/*	for(i=10; i>0; i--)
		printf("%d ",i);
*/
/*(ix)*/ 
/*	for(i=15; i>=0; i=i-3)
		printf("%d ",i);
*/

/*(x)*/ 
/*	for(i=10; i>=0; i--);  
		printf("%d ",i);
*/

/*(xi)*/ 
/*	for(i=0; i>10; i++)   
		printf("%d ",i);
*/

/*(xii)*/ 
/*	for(i=0; i<=10; i+=20)  
		printf("%d ",i);
*/

/*(xiii)*/ 
/*	for(i=1;  i!=10;  i=i+2)  
  		printf("%d ",i);
*/

/*(xiv)*/ 
/*	for(j=10; i=j; j-=2)
		printf("%d ",i);
*/

/*(xv)*/  
/*	for(i=10; i--; )  
		printf("%d ",i);
*/
return 0;
}
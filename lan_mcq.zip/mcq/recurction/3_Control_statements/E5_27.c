/*E5_27*/
#include<stdio.h>
int main(void)
{
	int i=10;
	do
	{
		printf("i=%d\t",i);
		i=i-3;
	}while(i);
	return 0;
}
/*E9.15*/                                                                                                                             
#include<stdio.h>
int main(void)
{
	int x,arr[8]={11,22,33,44,55,66,77,88};
	x=(arr+2)[3];
	printf("%d\n",x);
	return 0;
}
                  

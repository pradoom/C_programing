/*E9.33*/
#include<stdio.h>
int main(void)
{
	int a[5]={1},b[5]={1};
	if(a==b)
		printf("Same\n");
	else
		printf("Different\n");
	return 0;
}
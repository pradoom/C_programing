/*E4.16*/
#include<stdio.h>
int main(void)
{
	int a=5, b=6;
	printf("%d\t",a=b);
	printf("%d\t",a==b);
	printf("%d  %d\n",a,b);
	return 0;
}
	

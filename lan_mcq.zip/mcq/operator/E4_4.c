/*E4.4*/
#include<stdio.h>
int main(void)
{
	int a=5;
	a=6;
	a=a+5*a;
	printf("a=%d\n",a);
	return 0;
}
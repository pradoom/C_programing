/*E4.11*/
#include<stdio.h>
int main(void)
{
	float b;
	b = 15/2;
	printf("%f\t",b);
	b = (float)15/2 + (15/2);
	printf("%f\n",b);
	return 0;
}
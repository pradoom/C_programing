/*E14.3*/
#include<stdio.h>
int main(void)
{
	int k;
	k=((3<<4)^(96>>1));	
	printf("%d\n",k);
	return 0;
}
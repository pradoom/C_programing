/*E4.23*/
#include<stdio.h>
int main(void)
{
	int n;
	printf("Enter a number : ");
	scanf("%d",&n);
	printf("Remainder = %d\n",n%3);
	return 0;
}
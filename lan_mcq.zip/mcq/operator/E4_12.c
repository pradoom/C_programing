/*E4.12*/
#include<stdio.h>
int main(void)
{
	int a=9;
	char ch='A';
	a=a+ch+24;
	printf("%d,%c\t%d,%c\n",ch,ch,a,a);
	return 0;
}
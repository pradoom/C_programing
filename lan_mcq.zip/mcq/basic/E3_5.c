/*E3.5*/
#include<stdio.h>
int main(void)
{
	char ch;
	printf("Enter a character : ");
	scanf("%c",&ch);
	printf("%d\n",ch);
	return 0;
}
/*E3.7*/
#include<stdio.h>
int main(void)
{
	int a=625,b=2394,c=12345;
	printf("%5d,%5d,%5d\n",a,b,c);
	printf("%3d,%4d,%5d\n",a,b,c);
	return 0;
}